import streamlit as st
import pandas as pd
import plotly.express as px
import os

# =========================================================
# PAGE CONFIG (DO NOT TOUCH)
# =========================================================
st.set_page_config(
    page_title="Network Intrusion Detection — Dataset & Model Monitoring",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =========================================================
# 🔧 FIX: HEADER CUT-OFF ISSUE (SAFE & MINIMAL)
# =========================================================
st.markdown(
    """
    <style>
    /* Add top padding so title is not clipped */
    .block-container {
        padding-top: 3rem !important;
    }

    /* Ensure large headers are fully visible */
    h1 {
        line-height: 1.25 !important;
        margin-top: 0.5rem !important;
        padding-top: 0.5rem !important;
        overflow: visible !important;
    }

    h2, h3 {
        overflow: visible !important;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# =========================================================
# PATHS
# =========================================================
DATA_PATH = "data/processed/processed_dataset.csv"
APP_DIR = os.path.dirname(__file__)
TEESSIDE_LOGO = os.path.join(APP_DIR, "teesside.png")
MDIS_LOGO = os.path.join(APP_DIR, "mdis.png")

# =========================================================
# LOAD DATA
# =========================================================
@st.cache_data
def load_data():
    if not os.path.exists(DATA_PATH):
        return None
    return pd.read_csv(DATA_PATH)

df = load_data()

# =========================================================
# SIDEBAR
# =========================================================
st.sidebar.title("Controls")
view = st.sidebar.radio(
    "View",
    ["Overview", "Data", "Model", "Explainability", "Live Monitor"]
)

sample_size = st.sidebar.slider(
    "Sample size for visuals",
    100, 5000, 1000, step=100
)

show_raw = st.sidebar.checkbox("Show raw table")
st.sidebar.button("Refresh")

# =========================================================
# HEADER (UNCHANGED)
# =========================================================
col1, col2, col3 = st.columns([1.2, 6, 1.2])

with col1:
    st.image(TEESSIDE_LOGO, width=120)

with col2:
    st.markdown(
        """
        <h1 style="text-align:center;">
        Network Intrusion Detection — Dataset & Model Monitoring
        </h1>
        <p style="text-align:center; font-size:18px; color:#f59e0b;">
        Explainable AI-enabled NIDS using CIC-IDS 2017 dataset • SOC-style dashboard
        </p>
        """,
        unsafe_allow_html=True
    )

with col3:
    st.image(MDIS_LOGO, width=120)

st.markdown("---")

# =========================================================
# STATUS
# =========================================================
if df is None:
    st.error("Processed dataset missing. Run preprocess.py first.")
    st.stop()
else:
    st.success("Status: Ready")

# =========================================================
# OVERVIEW PAGE
# =========================================================
if view == "Overview":
    st.header("SOC Operations Overview")

    total_flows = len(df)
    features = df.shape[1] - 1
    classes = df["label"].nunique()
    benign = int((df["label"] == 0).sum())
    attacks = int((df["label"] == 1).sum())

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total Flows", f"{total_flows:,}")
    c2.metric("Features", features)
    c3.metric("Classes", classes)
    c4.metric("Benign", f"{benign:,}")
    c5.metric("Attacks", f"{attacks:,}")

    st.subheader("Traffic trend (sampled batches)")
    sample_df = df.sample(min(sample_size, len(df)))
    sample_df["batch"] = range(len(sample_df))

    fig = px.area(
        sample_df,
        x="batch",
        y=sample_df.index
    )
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Class distribution")
    class_counts = df["label"].value_counts().reset_index()
    class_counts.columns = ["label", "count"]

    fig2 = px.pie(
        class_counts,
        names="label",
        values="count",
        hole=0.55
    )
    st.plotly_chart(fig2, use_container_width=True)

# =========================================================
# DATA PAGE
# =========================================================
elif view == "Data":
    st.header("Dataset Exploration")
    if show_raw:
        st.dataframe(df.head(1000))
    st.write("Shape:", df.shape)

# =========================================================
# MODEL PAGE
# =========================================================
elif view == "Model":
    st.header("Model Performance")
    st.info("Model metrics loaded from training pipeline.")

# =========================================================
# EXPLAINABILITY PAGE
# =========================================================
elif view == "Explainability":
    st.header("Explainability — SHAP & LIME")
    st.info("SHAP and LIME visualizations generated offline.")

# =========================================================
# LIVE MONITOR
# =========================================================
elif view == "Live Monitor":
    st.header("Live Flow Monitoring (Simulated)")
    st.warning("Live data stream simulation placeholder.")
